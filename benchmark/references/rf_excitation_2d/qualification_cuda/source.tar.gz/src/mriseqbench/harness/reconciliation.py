"""Durable, credential-free queue for late OpenRouter billing metadata.

The detached host worker only makes generation-metadata GETs. It never resumes
an agent or changes a scientific verdict. Credentials exist only in its environment.
"""

import argparse
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

from ..io import write_json
from ..models import ApiProxyConfig
from .accounting import (
    read_api,
    summarize_api,
    summarize_trials,
    usage_complete,
    utc_now,
)
from .proxy import ApiProxy


@contextmanager
def receipt_lock(directory):
    path = Path(directory) / ".accounting.lock"
    with path.open("a") as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)


def pending_rows(path, config):
    rows, _ = read_api(path)
    return [
        row
        for row in rows
        if not usage_complete(row)
        or (row.get("usage") or {}).get("cost_credits") is None
        or (config.provider_endpoint and not row.get("provider"))
    ]


def enqueue(directory, config, model, queue):
    directory, queue = Path(directory).resolve(), Path(queue).resolve()
    rows = pending_rows(directory / "api.jsonl", config)
    if not rows:
        return None
    queue.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = queue / (hashlib.sha256(str(directory).encode()).hexdigest() + ".job.json")
    if path.exists():
        return path
    write_json(
        path,
        {
            "schema_version": 1,
            "workspace": str(directory),
            "model": model,
            "config": config.model_dump(mode="json"),
            "created_at": utc_now(),
            "status": "pending"
            if any(row.get("generation_id") for row in rows)
            else "unrecoverable",
            "generation_ids": [
                row["generation_id"] for row in rows if row.get("generation_id")
            ],
            "requests_missing_generation_id": sum(
                not row.get("generation_id") for row in rows
            ),
            "rounds": 0,
            "wall_s": 0.0,
            "next_attempt_unix_s": time.time() + 10,
        },
    )
    return path


def refresh_receipts(directory, job):
    """Refresh accounting only; preserve all verdicts and measured execution time."""
    directory = Path(directory)
    with receipt_lock(directory):
        path = directory / "accounting.json"
        if not path.exists():
            return
        accounting = json.loads(path.read_text())
        if accounting.get("status") == "running":
            return
        accounting["usage"] = summarize_api(directory / "api.jsonl")
        accounting["deferred_reconciliation"] = {
            k: job[k] for k in ("status", "rounds", "wall_s", "updated_at")
        }
        write_json(path, accounting)
        result_path = directory / "result.json"
        if result_path.exists():
            result = json.loads(result_path.read_text())
            result["accounting"] = accounting
            write_json(result_path, result)
    campaign = directory.parent
    if not (campaign / "experiment.json").exists():
        return
    with receipt_lock(campaign):
        path = campaign / "accounting.json"
        if not path.exists():
            return
        accounting = json.loads(path.read_text())
        if accounting.get("status") == "running":
            return
        accounting.update(summarize_trials(campaign), accounting_updated_at=utc_now())
        write_json(path, accounting)
        results_path = campaign / "results.jsonl"
        if results_path.exists():
            results = [
                json.loads(line) for line in results_path.read_text().splitlines()
            ]
            for result in results:
                trial = Path(result["workspace"])
                if trial.parent == campaign and (trial / "accounting.json").exists():
                    result["accounting"] = json.loads(
                        (trial / "accounting.json").read_text()
                    )
            temporary = results_path.with_suffix(".jsonl.tmp")
            temporary.write_text(
                "".join(json.dumps(row, allow_nan=False) + "\n" for row in results)
            )
            temporary.replace(results_path)


def reconcile_job(path, remaining_s=None):
    job = json.loads(path.read_text())
    config = ApiProxyConfig.model_validate(job["config"])
    directory = Path(job["workspace"])
    accounting_path = directory / "accounting.json"
    if (
        not accounting_path.exists()
        or json.loads(accounting_path.read_text()).get("status") == "running"
    ):
        return False
    campaign = directory.parent
    if (campaign / "experiment.json").exists():
        campaign_accounting = campaign / "accounting.json"
        if not campaign_accounting.exists() or json.loads(campaign_accounting.read_text()).get("status") == "running":
            return False
    if not os.environ.get(config.key_env):
        job.update(last_error="missing_host_credential", updated_at=utc_now())
        write_json(path, job)
        return False
    # One lookup per generation per round. All unresolved IDs get a chance
    # before a persistent 404 can consume the deferred worker's whole lifetime.
    proxy = ApiProxy(
        config.model_copy(
            update={
                "reconciliation_attempts": 1,
                "reconciliation_timeout_s": min(
                    config.reconciliation_timeout_s, remaining_s
                )
                if remaining_s is not None
                else config.reconciliation_timeout_s,
            }
        ),
        directory / "api.jsonl",
        model=job.get("model"),
    )
    started = time.monotonic()
    try:
        with receipt_lock(directory):
            proxy.reconcile(start_request_id=job.get("next_request_id"))
    finally:
        proxy.httpd.server_close()  # No listening proxy/agent is started here.
    rows = pending_rows(directory / "api.jsonl", config)
    _, summary = read_api(directory / "api.jsonl")
    job.update(
        rounds=job["rounds"] + 1,
        wall_s=job["wall_s"] + time.monotonic() - started,
        updated_at=utc_now(),
        status="complete"
        if not rows
        else "pending"
        if any(r.get("generation_id") for r in rows)
        else "unrecoverable",
        generation_ids=[r["generation_id"] for r in rows if r.get("generation_id")],
        next_attempt_unix_s=time.time() + min(10 * 2 ** min(job["rounds"], 3), 60),
        next_request_id=(summary or {}).get("next_request_id"),
    )
    job.pop("last_error", None)
    refresh_receipts(directory, job)
    # Publish completion last: a crashed refresh leaves a resumable pending job.
    write_json(path, job)
    return True


def run_pending(queue, *, watch=False, timeout_s=300):
    queue = Path(queue).resolve()
    queue.mkdir(parents=True, exist_ok=True, mode=0o700)
    deadline = time.monotonic() + timeout_s
    processed = 0
    with (queue / ".worker.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {"status": "already_running", "processed": 0}
        while True:
            available = []
            for path in sorted(queue.glob("*.job.json")):
                job = json.loads(path.read_text())
                if job["status"] != "pending":
                    continue
                config = ApiProxyConfig.model_validate(job["config"])
                if not os.environ.get(config.key_env):
                    continue
                available.append((path, job))
            if not available:
                break
            for path, job in available:
                if time.monotonic() >= deadline:
                    break
                if not watch or job["next_attempt_unix_s"] <= time.time():
                    processed += reconcile_job(
                        path, max(0.001, deadline - time.monotonic())
                    )
            if not watch or time.monotonic() >= deadline:
                break
            # Sleep in short intervals; queue state stays durable across restarts.
            time.sleep(min(5, max(0, deadline - time.monotonic())))
    return {
        "status": "finished",
        "processed": processed,
        "pending": sum(
            json.loads(p.read_text())["status"] == "pending"
            for p in queue.glob("*.job.json")
        ),
    }


def launch_worker(queue):
    queue = Path(queue).resolve()
    if not queue.exists():
        return
    jobs = [json.loads(path.read_text()) for path in queue.glob("*.job.json")]
    jobs = [
        job
        for job in jobs
        if job["status"] == "pending" and os.environ.get(job["config"]["key_env"])
    ]
    if not jobs:
        return
    # Only host metadata credentials needed by queued jobs reach this process.
    env = {
        k: v
        for k, v in os.environ.items()
        if k
        in {
            "PATH",
            "PYTHONPATH",
            "VIRTUAL_ENV",
            "LANG",
            "LC_ALL",
            "SSL_CERT_FILE",
            "SSL_CERT_DIR",
            *[job["config"]["key_env"] for job in jobs],
        }
    }
    timeout = max(job["config"]["deferred_reconciliation_timeout_s"] for job in jobs)
    try:
        with (queue / "worker.log").open("a") as log:
            subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    __name__,
                    "--queue",
                    str(queue),
                    "--watch",
                    "--timeout-s",
                    str(timeout),
                ],
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=log,
                start_new_session=True,
                env=env,
            )
    except OSError as exc:
        write_json(
            queue / "worker-launch-error.json",
            {"error_type": type(exc).__name__, "at": utc_now()},
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--queue", type=Path, required=True)
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--timeout-s", type=float, default=300)
    args = parser.parse_args()
    print(
        json.dumps(run_pending(args.queue, watch=args.watch, timeout_s=args.timeout_s))
    )


if __name__ == "__main__":
    main()
