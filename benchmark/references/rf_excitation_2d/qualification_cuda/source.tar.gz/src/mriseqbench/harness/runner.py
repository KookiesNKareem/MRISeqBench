"""Prepared, sandboxed case/repeat runs with separate trusted evaluation."""

import copy
import json
import shutil
import subprocess
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import ExitStack
from datetime import UTC, datetime
from pathlib import Path

from ..io import write_json
from ..phantoms import materialize
from ..process import execute, expand
from .accounting import read_api, summarize_api, summarize_trials, utc_now
from .arm_mailbox import Mailbox
from .arm_runtime import Simulator, arm_environment, launch_arm, resolve_runtime
from .feedback import FeedbackServer
from .grading import grade_frozen
from .host_resources import guarded_benchmark
from .prepare import prepare, prepare_pi
from .proxy import ApiProxy
from .reconciliation import enqueue, launch_worker, receipt_lock
from .sandbox import environment, launch


class ModelAPIError(RuntimeError):
    """Inference infrastructure failed before a candidate could be scored."""


def pi_session_settings(workspace, configured_effort):
    levels = []
    for path in sorted((Path(workspace) / "transcript").glob("*.jsonl")):
        with path.open() as stream:
            for line in stream:
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                if (
                    isinstance(row, dict)
                    and row.get("type") == "thinking_level_change"
                    and row.get("thinkingLevel")
                    in {"off", "minimal", "low", "medium", "high", "xhigh", "max"}
                ):
                    levels.append(row["thinkingLevel"])
    return {
        "requested_thinking_level": "off"
        if configured_effort == "none"
        else configured_effort,
        "session_reported_thinking_levels": list(dict.fromkeys(levels)),
        "host_enforced_reasoning_effort": configured_effort,
    }


def final_evaluation(source, case, experiment, root, workspace):
    judge_dir = workspace / "evaluation"
    if (
        not source.is_file()
        or source.is_symlink()
        or source.stat().st_size > experiment.feedback.max_submission_bytes
    ):
        return {
            "case_id": case["case_id"],
            "status": "failed",
            "checks": [],
            "metrics": {},
            "reason": "Final submission is missing, a symlink, or oversized",
        }
    snapshot = judge_dir / "sequence.seq"
    shutil.copyfile(source, snapshot)
    write_json(judge_dir / "case.json", case)
    return grade_frozen(
        snapshot,
        case,
        root,
        judge_dir,
        experiment.feedback.timeout_s,
        execute,
        backend_path=workspace / "control/backend.json" if experiment.backend else None,
    )


@guarded_benchmark
def run_one(
    catalog,
    experiment,
    case,
    workspace,
    repeat,
    phantom_dir=None,
    *,
    runtime=None,
    grading_slots=None,
    abort_event=None,
    deferred_queue=None,
    defer_reconciliation=False,
):
    """Persist accounting even when setup or trusted evaluation interrupts a trial."""
    experiment.require_run_controls()
    workspace = Path(workspace)
    workspace.mkdir(parents=True, exist_ok=True)
    deferred_queue = (
        Path(deferred_queue)
        if deferred_queue
        else catalog.root / "runs/.reconciliation"
    )
    if (workspace / "accounting.json").exists():
        raise FileExistsError(f"Trial accounting already exists: {workspace}")
    started = time.monotonic()
    accounting = {
        "schema_version": 1,
        "started_at": utc_now(),
        "status": "running",
        "setup_wall_s": None,
        "agent_wall_s": None,
        "agent_charged_wall_s": None,
        "agent_excluded_grading_wall_s": None,
        "julia_setup_wall_s": None,
        "grading_wall_s": None,
        "post_agent_evaluation_wall_s": 0.0,
    }
    write_json(workspace / "accounting.json", accounting)
    report = None
    try:
        report = _run_one(
            catalog,
            experiment,
            case,
            workspace,
            repeat,
            phantom_dir,
            runtime=runtime,
            accounting=accounting,
            trial_started=started,
            grading_slots=grading_slots,
            abort_event=abort_event,
        )
        accounting["status"] = "finished"
    except BaseException as exc:
        accounting.update(status="interrupted", error_type=type(exc).__name__)
        raise
    finally:
        usage = summarize_api(
            workspace / "api.jsonl", configured=experiment.api_proxy is not None
        )
        accounting.update(
            finished_at=utc_now(),
            wall_s=time.monotonic() - started,
            usage=usage,
            reconciliation_wall_s=(usage.get("reconciliation") or {}).get(
                "wall_s", 0.0
            ),
        )
        with receipt_lock(workspace):
            write_json(workspace / "accounting.json", accounting)
        if experiment.api_proxy:
            queued = enqueue(
                workspace, experiment.api_proxy, experiment.agent.model, deferred_queue
            )
            if queued and report is None and not defer_reconciliation:
                launch_worker(deferred_queue)
    with receipt_lock(workspace):
        # A resumed metadata worker may have refreshed this trial already.
        report["accounting"] = json.loads((workspace / "accounting.json").read_text())
        write_json(workspace / "result.json", report)
    if experiment.api_proxy and not defer_reconciliation:
        launch_worker(deferred_queue)
    return report


def _run_one(
    catalog,
    experiment,
    case,
    workspace,
    repeat,
    phantom_dir=None,
    *,
    runtime=None,
    accounting,
    trial_started,
    grading_slots=None,
    abort_event=None,
):
    if experiment.arm is not None or experiment.arm_runtime is not None:
        experiment = type(experiment).model_validate(experiment.model_dump(mode="json"))
    arm = catalog.get("arms", experiment.arm) if experiment.arm else None
    if arm and runtime is None:
        runtime = resolve_runtime(experiment, arm)
    if arm and runtime["arm"] != arm.model_dump(mode="json"):
        raise ValueError("resolved runtime does not match the selected arm")
    agent_dir, judge_dir = workspace / "agent", workspace / "evaluation"
    agent_dir.mkdir(parents=True, mode=0o700)
    judge_dir.mkdir()
    with ExitStack() as stack:
        server = stack.enter_context(
            FeedbackServer(
                case,
                experiment.feedback,
                catalog.root,
                workspace / "control",
                experiment.backend,
                max_submissions=experiment.max_submissions,
                grading_slots=grading_slots,
            )
        )
        proxy = (
            stack.enter_context(
                ApiProxy(
                    experiment.api_proxy,
                    workspace / "api.jsonl",
                    model=experiment.agent.model or None,
                    stop_when=server.submitted,
                )
            )
            if experiment.api_proxy
            else None
        )
        prompt_path, case_path, submission = prepare(
            agent_dir, case, experiment, server, phantom_dir, arm=arm
        )
        values = {
            "prompt": prompt_path,
            "prompt_text": prompt_path.read_text(),
            "case": case_path,
            "submission": submission,
            "model": experiment.agent.model,
            "thinking_level": "off"
            if experiment.api_proxy and experiment.api_proxy.reasoning_effort == "none"
            else experiment.api_proxy.reasoning_effort
            if experiment.api_proxy
            else "off",
            "api_base_url": ("http://127.0.0.1:8765/api" if arm else proxy.base_url)
            if proxy
            else "",
            "api_token": proxy.token if proxy else "",
        }
        if arm:
            values["python"] = "python3"
        command = expand(experiment.agent.command, catalog.root, agent_dir, **values)
        executable = shutil.which(command[0]) if not arm else None
        if executable:
            command[0] = executable
        env = (arm_environment if arm else environment)(
            experiment.agent, catalog.root, agent_dir, **values
        )
        if experiment.agent.adapter == "pi":
            if not arm:
                actual = subprocess.run(
                    [command[0], "--version"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                    check=True,
                ).stdout.strip()
                if actual != experiment.agent.pi_version:
                    raise ValueError(
                        f"Pi version mismatch: expected {experiment.agent.pi_version}, found {actual}"
                    )
            env.update(prepare_pi(agent_dir, values["api_base_url"], experiment.agent))
            env["OPENROUTER_API_KEY"] = proxy.token
        if not arm:
            env["PATH"] = str(Path(command[0]).parent) + ":" + env["PATH"]
        ports = [server.port, *([proxy.port] if proxy else [])]
        simulator = None
        if arm:
            if arm.simulator != "none":
                frozen_inputs = workspace / "control/simulation_inputs"
                if (agent_dir / "inputs").exists():
                    shutil.copytree(agent_dir / "inputs", frozen_inputs)
                else:
                    frozen_inputs.mkdir()
                simulator = Simulator(
                    runtime,
                    experiment.arm_runtime,
                    agent_dir,
                    workspace / "control",
                    json.loads(case_path.read_text()),
                )
            stack.enter_context(
                Mailbox(workspace / "control/transport", server, proxy, simulator)
            )
        if proxy:
            # Cancel API streams before Mailbox waits for its workers, including
            # when setup/agent execution raises instead of returning normally.
            stack.callback(proxy.revoke)
        launcher = (
            launch_arm(runtime, command, agent_dir, workspace / "control", env)
            if arm
            else launch(
                experiment.agent.sandbox,
                command,
                catalog.root,
                agent_dir,
                workspace / "control",
                ports,
            )
        )
        with launcher as (isolated_command, isolation):
            agent_started = time.monotonic()
            credit_started = server.grading_credit()
            server.start_agent_clock(experiment.agent.timeout_s)
            accounting["setup_wall_s"] = agent_started - trial_started
            accounting["julia_setup_wall_s"] = isolation.get("julia_session", {}).get(
                "setup_elapsed_s"
            )
            try:

                class StopAgent:
                    def is_set(self):
                        if abort_event is not None and abort_event.is_set():
                            server.closed.set()
                            return True
                        return server.submitted.is_set()

                execution = execute(
                    isolated_command,
                    agent_dir,
                    experiment.agent.timeout_s,
                    workspace / "agent",
                    # The trusted Docker client needs the host's daemon/context.
                    # Container variables were already passed explicitly via --env;
                    # Docker does not inherit the client's environment into it.
                    env=None if arm else env,
                    stop_when=StopAgent(),
                    timeout_credit=server.grading_credit,
                )
                if abort_event is not None and abort_event.is_set():
                    raise RuntimeError("Campaign aborted; trial remains unscored")
            finally:
                elapsed = time.monotonic() - agent_started
                excluded = max(0.0, server.grading_credit() - credit_started)
                accounting.update(
                    agent_wall_s=elapsed,
                    agent_excluded_grading_wall_s=min(elapsed, excluded),
                    agent_charged_wall_s=max(0.0, elapsed - excluded),
                    grading_wall_s=server.grading_credit(),
                )
        if proxy:
            proxy.revoke()
            if proxy.policy_violations:
                raise RuntimeError(
                    f"Inference policy violation: {proxy.policy_violations}"
                )
        if server.submitted.is_set():
            source = server.submission_path
        elif (
            execution["status"] == "completed" and experiment.submission_mode == "file"
        ):
            source = submission
            if (
                experiment.max_submissions > 1
                and not server.submissions_started
                and submission.is_file()
                and not submission.is_symlink()
                and submission.stat().st_size
                <= experiment.feedback.max_submission_bytes
            ):
                server.handle("submit", server.token, submission.read_bytes())
        else:
            source = None
        # Drain any accepted attempt whose evaluator was active at the deadline.
        with server.lock:
            attempts = list(server.attempts)
            if server.evaluation_failure is not None:
                raise server.evaluation_failure
            if server.submitted.is_set():
                source = server.submission_path
        server.closed.set()
        report = {
            "case_id": case["case_id"],
            "status": "agent_not_submitted"
            if execution["status"] == "completed"
            else f"agent_{execution['status']}",
            "checks": [],
            "metrics": {},
        }
        if attempts:
            # Reuse the immutable attempt verdict; never regrade changed agent files.
            report = dict(attempts[-1]["evaluation"])
            shutil.copyfile(server.submission_path, judge_dir / "sequence.seq")
            write_json(judge_dir / "case.json", case)
            write_json(judge_dir / "result.json", report)
        elif source is not None:
            grading_started = time.monotonic()
            try:
                with grading_slots or threading.BoundedSemaphore(1):
                    report = final_evaluation(
                        source, case, experiment, catalog.root, workspace
                    )
            finally:
                accounting["post_agent_evaluation_wall_s"] = (
                    time.monotonic() - grading_started
                )
                accounting["grading_wall_s"] = (
                    server.grading_credit() + accounting["post_agent_evaluation_wall_s"]
                )
        report.update(
            repeat=repeat,
            prompt_mode=case["task"].get("prompt_mode", "detailed"),
            web_access=False,
            task_family=case["task"]["id"],
            agent=execution,
            pi_version=experiment.agent.pi_version
            if experiment.agent.adapter == "pi"
            else None,
            auto_compaction=experiment.agent.auto_compaction,
            cache_warming="off",
            pi_settings=pi_session_settings(
                agent_dir, experiment.api_proxy.reasoning_effort
            )
            if experiment.agent.adapter == "pi"
            else None,
            isolation=isolation,
            feedback=server.stats(),
            api_requests=proxy.requests if proxy else 0,
            workspace=str(workspace),
            submissions=attempts,
            first_submission_status=attempts[0]["evaluation"]["status"]
            if attempts
            else None,
            passed_on_submission=next(
                (
                    a["attempt"]
                    for a in attempts
                    if a["evaluation"]["status"] in ("passed", "smoke_passed")
                ),
                None,
            ),
        )
        accounting["grading_wall_s"] = (
            server.grading_credit() + accounting["post_agent_evaluation_wall_s"]
        )
        accounting["feedback_wall_s"] = server.seconds
        if arm:
            report.update(
                arm=experiment.arm,
                authoring=arm.authoring,
                simulator=arm.simulator,
                simulation_calls=simulator.calls if simulator else [],
            )
    if proxy and proxy.policy_violations:
        raise RuntimeError(f"Inference policy violation: {proxy.policy_violations}")
    if proxy and report["status"].startswith("agent_"):
        requests, _ = read_api(workspace / "api.jsonl")
        # Pi can exit successfully after an API error. A terminal routing/provider
        # failure is an interrupted trial, even when earlier calls succeeded.
        last = requests[-1] if requests else {}
        if (
            last.get("provider_error")
            or (last.get("status") or 0) >= 400
            or (
                requests
                and last.get("status") is None
                and execution["status"] == "completed"
            )
        ):
            raise ModelAPIError(
                f"Model API failed before submission (HTTP {last.get('status')}); "
                "trial remains unscored; see api.jsonl and agent stdout"
            )
    return report


@guarded_benchmark
def run(catalog, experiment, output=None):
    started, started_at = time.monotonic(), utc_now()
    experiment.require_run_controls()
    deferred_queue = catalog.root / "runs/.reconciliation"
    launch_worker(deferred_queue)  # Resume durable jobs from earlier campaigns.
    # Validate before creating output, materializing phantoms, or starting agents.
    if experiment.arm is not None or experiment.arm_runtime is not None:
        experiment = type(experiment).model_validate(experiment.model_dump(mode="json"))
    arm = catalog.get("arms", experiment.arm) if experiment.arm else None
    runtime = resolve_runtime(experiment, arm) if arm else None
    cases = catalog.cases(catalog.get("suites", experiment.suite))
    output = (
        Path(output).resolve()
        if output
        else catalog.root
        / "runs"
        / (datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8])
    )
    output.mkdir(parents=True, exist_ok=False, mode=0o700)
    write_json(output / "experiment.json", experiment.model_dump(mode="json"))
    if runtime:
        write_json(output / "arm_runtime.json", runtime)
    reports = []
    ordered_reports = {}
    result_lock = threading.Lock()
    grading_slots = threading.BoundedSemaphore(experiment.concurrency.graders)
    failed = threading.Event()
    campaign = {
        "schema_version": 1,
        "scope": "campaign",
        "started_at": started_at,
        "status": "running",
    }
    write_json(output / "accounting.json", campaign)
    try:
        jobs = []
        for case in cases:
            case["seed"] = experiment.seed
            phantom_dir = None
            if case["evaluation"]["scope"] == "benchmark" or (
                arm and arm.simulator != "none"
            ):
                phantom_dir = output / "phantoms" / case["case_id"]
                materialize(case, catalog.root, phantom_dir)
            for repeat in range(experiment.repeats):
                workspace = output / f"{case['case_id']}--r{repeat}"
                jobs.append((copy.deepcopy(case), workspace, repeat, phantom_dir))

        def job(index, case, workspace, repeat, phantom_dir):
            if failed.is_set():
                return
            try:
                report = run_one(
                    catalog,
                    experiment,
                    case,
                    workspace,
                    repeat,
                    phantom_dir,
                    runtime=runtime,
                    grading_slots=grading_slots,
                    abort_event=failed,
                    deferred_queue=deferred_queue,
                    defer_reconciliation=True,
                )
            except BaseException:
                failed.set()
                raise
            with result_lock, receipt_lock(output):
                ordered_reports[index] = report
                with (output / "results.jsonl").open("a") as stream:
                    stream.write(json.dumps(report, allow_nan=False) + "\n")
                campaign.update(
                    summarize_trials(output), wall_s=time.monotonic() - started
                )
                write_json(output / "accounting.json", campaign)
                print(
                    f"{case['case_id']} repeat={repeat}: {report['status']}", flush=True
                )

        pool = ThreadPoolExecutor(max_workers=experiment.concurrency.agents)
        futures = [pool.submit(job, index, *args) for index, args in enumerate(jobs)]
        try:
            for future in as_completed(futures):
                future.result()
        finally:
            failed.set()
            pool.shutdown(wait=True, cancel_futures=True)
        reports = [ordered_reports[index] for index in sorted(ordered_reports)]
        campaign["status"] = "finished"
    except BaseException as exc:
        campaign.update(status="interrupted", error_type=type(exc).__name__)
        raise
    finally:
        campaign.update(
            summarize_trials(output),
            finished_at=utc_now(),
            wall_s=time.monotonic() - started,
        )
        with receipt_lock(output):
            write_json(output / "accounting.json", campaign)
        launch_worker(deferred_queue)
    return output, reports
