"""Fail-closed macOS host admission and independent resource watchdog.

This file is also an executable stdlib-only guardian, so a busy Python agent
or a blocked API call cannot prevent host sampling and emergency cleanup.
"""

import contextlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

GIB = 1024**3
MIB = 1024**2
LEASE_ENV = "MRISEQBENCH_HOST_GUARD"


class HostResourceStop(RuntimeError):
    """Infrastructure interruption; never a scientific/model verdict."""


@dataclass(frozen=True)
class Policy:
    admission_free_percent: int = 30
    stop_free_percent: int = 20
    admission_disk_bytes: int = 16 * GIB
    stop_disk_bytes: int = 12 * GIB
    max_swap_bytes: int = 4 * GIB
    max_swap_growth_bytes: int = 512 * MIB
    max_swapout_window_bytes: int = 256 * MIB
    swap_window_s: int = 30
    max_compressor_fraction: float = 0.50
    interval_s: float = 2
    stale_s: float = 10


def write(path, value):
    path = Path(path)
    temp = path.with_name(path.name + f".{os.getpid()}.tmp")
    temp.write_text(json.dumps(value, allow_nan=False) + "\n")
    temp.replace(path)


def output(command):
    return subprocess.run(
        command, capture_output=True, text=True, check=True, timeout=2
    ).stdout


def parse_sample(sysctl, pressure, vm, disk_free_bytes, now=None):
    def number(pattern, text):
        match = re.search(pattern, text)
        if not match:
            raise ValueError(f"Missing host telemetry: {pattern}")
        return float(match.group(1))

    physical = int(number(r"hw.memsize:\s*(\d+)", sysctl))
    level = int(number(r"kern.memorystatus_vm_pressure_level:\s*(\d+)", sysctl))
    # Swap is lazily allocated: total=free=0 with used=0 is a healthy reading.
    swap = re.search(r"used\s*=\s*([\d.]+)([KMG])", sysctl)
    if not swap:
        raise ValueError("Missing swap usage")
    used = float(swap[1]) * {"K": 1024, "M": MIB, "G": GIB}[swap[2]]
    page = number(r"page size of\s+(\d+)\s+bytes", vm)
    compressor = number(r"Pages occupied by compressor:\s*(\d+)", vm) * page
    swapouts = number(r"Swapouts:\s*(\d+)", vm) * page
    free = number(r"System-wide memory free percentage:\s*(\d+)%", pressure)
    if physical <= 0 or not 0 <= free <= 100 or level not in {1, 2, 4}:
        raise ValueError("Invalid host telemetry")
    return {
        "sampled_at_unix_s": time.time() if now is None else now,
        "physical_bytes": physical,
        "pressure_level": level,
        "memory_free_percent": free,
        "swap_used_bytes": used,
        "compressor_bytes": compressor,
        "swapout_bytes": swapouts,
        "disk_free_bytes": disk_free_bytes,
    }


def sample(root):
    if sys.platform != "darwin":
        raise HostResourceStop("The laptop resource policy requires macOS telemetry")
    return parse_sample(
        output(
            [
                "sysctl",
                "hw.memsize",
                "kern.memorystatus_vm_pressure_level",
                "vm.swapusage",
            ]
        ),
        output(["memory_pressure"]),
        output(["vm_stat"]),
        min(shutil.disk_usage(root).free, shutil.disk_usage("/private/var/vm").free),
    )


class Assessment:
    def __init__(self, policy=None):
        self.policy = policy or Policy()
        self.baseline_swap = None
        self.history = []

    def reason(self, row, *, admission=False, now=None):
        p = self.policy
        now = time.time() if now is None else now
        if now - row["sampled_at_unix_s"] > p.stale_s:
            return "host telemetry is stale"
        if row["pressure_level"] != 1:
            return "macOS memory pressure is warning or critical"
        if row["memory_free_percent"] < (
            p.admission_free_percent if admission else p.stop_free_percent
        ):
            return "insufficient whole-host memory headroom"
        if row["disk_free_bytes"] < (
            p.admission_disk_bytes if admission else p.stop_disk_bytes
        ):
            return "insufficient disk headroom for swap and checkpoints"
        if row["swap_used_bytes"] > p.max_swap_bytes:
            return "whole-host swap usage exceeds 4 GiB"
        if row["compressor_bytes"] / row["physical_bytes"] >= p.max_compressor_fraction:
            return "compressed memory occupies half of physical RAM"
        if self.baseline_swap is None:
            self.baseline_swap = row["swap_used_bytes"]
        if row["swap_used_bytes"] - self.baseline_swap >= p.max_swap_growth_bytes:
            return "whole-host swap grew by at least 512 MiB"
        self.history.append(row)
        while (
            len(self.history) > 1
            and self.history[0]["sampled_at_unix_s"] < now - p.swap_window_s
        ):
            self.history.pop(0)
        if (
            row["swapout_bytes"] - self.history[0]["swapout_bytes"]
            >= p.max_swapout_window_bytes
        ):
            return "at least 256 MiB swapped out within 30 seconds"
        return None


def require_lease(directory=None, *, admission=False):
    directory = Path(directory or os.environ[LEASE_ENV])
    state = json.loads((directory / "state.json").read_text())
    if (
        state.get("status") != "armed"
        or time.time() - state["heartbeat_unix_s"] > Policy().stale_s
    ):
        raise HostResourceStop("Host guardian stopped or its lease expired")
    if admission:
        reason = Assessment().reason(state["sample"], admission=True)
        if reason:
            raise HostResourceStop(reason)
    return state


def register_container(name):
    if directory := os.environ.get(LEASE_ENV):
        require_lease(directory, admission=True)
        with (Path(directory) / "containers.jsonl").open("a") as stream:
            stream.write(json.dumps({"name": name}) + "\n")


def processes():
    rows = {}
    for line in output(["ps", "-axo", "pid=,ppid=,pgid=,lstart="]).splitlines():
        pid, parent, group, birth = line.split(maxsplit=3)
        rows[int(pid)] = (int(parent), int(group), birth)
    return rows


def descendants(rows, parent):
    found = {parent}
    while True:
        more = found | {pid for pid, row in rows.items() if row[0] in found}
        if more == found:
            return found - {parent}
        found = more


def same_process(left, right):
    # Parent PID changes when an owned process becomes orphaned. Its process
    # group and birth time still identify it; ancestry alone is not identity.
    return left is not None and right is not None and left[1:] == right[1:]


def terminate_owned(parent, known, directory, *, grace_s=3):
    """Kill only recorded descendants with matching process start identities."""
    initial = processes()
    if parent in initial:
        known.setdefault(parent, initial[parent])
        if same_process(known[parent], initial[parent]):
            with contextlib.suppress(ProcessLookupError):
                os.kill(parent, signal.SIGINT)
    # Docker containers outlive their clients; remove explicitly registered names.
    journal = Path(directory) / "containers.jsonl"
    names = set()
    try:
        lines = journal.read_text().splitlines()
    except OSError:
        lines = []
    for line in lines:
        try:
            names.add(json.loads(line)["name"])
        except (ValueError, KeyError, TypeError):
            # A partial final append must not prevent native process cleanup.
            continue

    def remove():
        if names:
            try:
                subprocess.run(
                    ["docker", "rm", "-f", *sorted(names)],
                    capture_output=True,
                    timeout=3,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                pass

    cleanup = threading.Thread(target=remove, daemon=True)
    cleanup.start()
    time.sleep(grace_s)
    try:
        live = processes()
        if same_process(live.get(parent), known.get(parent)):
            known.update({pid: live[pid] for pid in descendants(live, parent)})
        for pid, identity in known.items():
            if pid != os.getpid() and same_process(live.get(pid), identity):
                with contextlib.suppress(ProcessLookupError):
                    os.kill(pid, signal.SIGKILL)
    finally:
        cleanup.join(1)


def guardian(parent, directory, root):
    directory, root = Path(directory), Path(root)
    assess = Assessment()
    known = {}
    while not (directory / "release").exists():
        try:
            rows = processes()
            if parent in rows:
                known.setdefault(parent, rows[parent])
            if parent not in rows or not same_process(rows[parent], known[parent]):
                raise HostResourceStop("guarded process disappeared")
            known.update(
                {
                    pid: rows[pid]
                    for pid in descendants(rows, parent)
                    if pid != os.getpid()
                }
            )
            row = sample(root)
            reason = assess.reason(row)
            if reason:
                raise HostResourceStop(reason)
            write(
                directory / "state.json",
                {
                    "status": "armed",
                    "heartbeat_unix_s": time.time(),
                    "guardian_pid": os.getpid(),
                    "parent_pid": parent,
                    "sample": row,
                },
            )
            with (directory / "samples.jsonl").open("a") as stream:
                stream.write(json.dumps(row) + "\n")
        except Exception as exc:  # noqa: BLE001 - every telemetry failure must stop work
            try:
                write(
                    directory / "state.json",
                    {
                        "status": "stopped",
                        "heartbeat_unix_s": time.time(),
                        "reason": str(exc),
                        "error_type": type(exc).__name__,
                        "sample": locals().get("row"),
                    },
                )
                write(
                    directory / "stop.json",
                    json.loads((directory / "state.json").read_text()),
                )
            finally:
                # ENOSPC or a broken receipt directory must not leave expensive
                # work running while the guardian merely exits with an error.
                terminate_owned(parent, known, directory)
            return
        time.sleep(Policy().interval_s)


class HostGuard:
    """macOS default for all runs; an inherited guardian covers nested runs."""

    def __init__(self, root, receipts):
        self.root, self.receipts = Path(root), Path(receipts)
        self.proc = None
        self.closed = threading.Event()

    def __enter__(self):
        if inherited := os.environ.get(LEASE_ENV):
            require_lease(inherited, admission=True)
            return self
        if sys.platform != "darwin":
            return self  # This policy is specific to the user's macOS laptop.
        row = sample(self.root)
        if reason := Assessment().reason(row, admission=True):
            raise HostResourceStop(reason)
        self.directory = self.receipts / ("host-guard-" + uuid.uuid4().hex[:10])
        self.directory.mkdir(parents=True)
        write(self.directory / "policy.json", asdict(Policy()))
        self.proc = subprocess.Popen(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "guardian",
                str(os.getpid()),
                str(self.directory),
                str(self.root),
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        deadline = time.monotonic() + 8
        while not (self.directory / "state.json").exists():
            if self.proc.poll() is not None or time.monotonic() >= deadline:
                (self.directory / "release").touch()
                self.proc.terminate()
                self.proc.wait(timeout=3)
                raise HostResourceStop("Host guardian did not become ready")
            time.sleep(0.05)
        require_lease(self.directory, admission=True)
        os.environ[LEASE_ENV] = str(self.directory)
        self.deadman = threading.Thread(target=self._deadman, daemon=True)
        self.deadman.start()
        return self

    def _deadman(self):
        while not self.closed.wait(1):
            try:
                require_lease(self.directory)
                if self.proc.poll() is not None:
                    raise HostResourceStop("Host guardian exited unexpectedly")
            except Exception:  # noqa: BLE001 - rescue must also cover malformed leases
                # A separate rescue process survives Python unwinding/exit and
                # kills detached graders as well as the agent's Docker client.
                subprocess.Popen(
                    [
                        sys.executable,
                        str(Path(__file__).resolve()),
                        "cleanup",
                        str(os.getpid()),
                        str(self.directory),
                    ],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                return

    def __exit__(self, *args):
        if self.proc:
            self.closed.set()
            (self.directory / "release").touch()
            os.environ.pop(LEASE_ENV, None)
            try:
                self.proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait()


def guarded_benchmark(function):
    """Guard before runtime probes, phantoms, containers or model requests."""
    import functools

    @functools.wraps(function)
    def wrapped(catalog, experiment, *args, **kwargs):
        with HostGuard(catalog.root, catalog.root / "runs/.host-resources"):
            return function(catalog, experiment, *args, **kwargs)

    return wrapped


if __name__ == "__main__":
    if sys.argv[1] == "cleanup":
        parent = int(sys.argv[2])
        rows = processes()
        known = {
            pid: rows[pid] for pid in descendants(rows, parent) if pid != os.getpid()
        }
        terminate_owned(parent, known, sys.argv[3])
    else:
        guardian(int(sys.argv[2]), sys.argv[3], sys.argv[4])
