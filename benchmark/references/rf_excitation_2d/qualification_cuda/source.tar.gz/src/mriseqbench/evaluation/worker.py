"""Killable host-side preflight/evaluation worker used by the feedback server."""

import argparse
import json
from pathlib import Path

from ..io import write_json
from ..models import Backend
from . import evaluate, preflight


def main():
    p = argparse.ArgumentParser()
    p.add_argument(
        "--mode", choices=["lint", "preflight", "evaluation", "feedback"], required=True
    )
    p.add_argument("--case", required=True, type=Path)
    p.add_argument("--submission", required=True, type=Path)
    p.add_argument("--root", required=True, type=Path)
    p.add_argument("--workspace", required=True, type=Path)
    p.add_argument("--backend", type=Path)
    p.add_argument("--time-budget-s", type=float)
    args = p.parse_args()
    case = json.loads(args.case.read_text())
    if args.mode in ("lint", "preflight"):
        checks = preflight(args.submission, case, hardware_limits=args.mode != "lint")
        result = {
            "case_id": case["case_id"],
            "status": ("lint_passed" if args.mode == "lint" else "preflight_passed")
            if all(c["passed"] for c in checks)
            else "failed",
            "checks": checks,
            "metrics": {},
        }
    else:
        backend = (
            Backend.model_validate(json.loads(args.backend.read_text()))
            if args.backend
            else None
        )
        result = evaluate(
            args.submission,
            case,
            args.root,
            args.workspace / "physical",
            backend,
            feedback=args.mode == "feedback",
            time_budget_s=args.time_budget_s,
        )
    write_json(args.workspace / "result.json", result)


if __name__ == "__main__":
    main()
